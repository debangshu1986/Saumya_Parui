//charAt
var str = new String("This is string");
console.log("str.charAt(0) is:" + str.charAt(0));
console.log("str.charAt(1) is:" + str.charAt(1));
//indexOf
var str1 = new String("This is string one");
var index = str1.indexOf("string");
console.log("indexOf found String :" + index);
var index = str1.indexOf("one");
console.log("indexOf found String :" + index);
//split
var str2 = "Apples are round, and apples are juicy.";
var splitted = str2.split(" ");
console.log(splitted);
//substr
var str3 = "Apples are round, and apples are juicy.";
console.log("(1,2): " + str3.substr(1, 2));
console.log("(-2, 2): " + str3.substr(-2, 2));
//substring
var str4 = "Apples are round, and apples are juicy.";
console.log("(1,2): " + str4.substring(1, 2));
console.log("(-2, 2): " + str4.substring(-2, 2));
//toLowerCase
var str5 = "Apples are round, and Apples are Juicy.";
console.log(str5.toLowerCase());
//toUpperCase
var str6 = "Apples are round, and Apples are Juicy.";
console.log(str6.toUpperCase());
