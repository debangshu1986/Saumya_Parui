export interface IShape { 
    draw(); 
}
