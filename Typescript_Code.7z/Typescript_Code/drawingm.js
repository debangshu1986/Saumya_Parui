"use strict";
exports.__esModule = true;
var Circle = /** @class */ (function () {
    function Circle() {
    }
    Circle.prototype.draw = function () {
        console.log("Circle is drawn");
    };
    return Circle;
}());
exports.Circle = Circle;
var Triangle = /** @class */ (function () {
    function Triangle() {
    }
    Triangle.prototype.draw = function () {
        console.log("Triangle is drawn");
    };
    return Triangle;
}());
exports.Triangle = Triangle;
function drawAllShapes(shape) {
    shape.draw();
}
drawAllShapes(new Circle());
drawAllShapes(new Triangle());
