var msg = "hello" + "world"; // Concatenation operator (+)
console.log(msg);
var num = -2;
var result = num > 0 ? "positive" : "non-positive"; //Conditional Operator (?)
console.log(result);
var num = 12;
console.log(typeof num); //typeof operator
