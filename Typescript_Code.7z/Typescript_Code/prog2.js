var firstName = "John";
var score1 = 50;
var score2 = 42.50;
var sum = score1 + score2;
console.log("First Name " + firstName);
console.log("first score: " + score1);
console.log("second score: " + score2);
console.log("sum of the scores: " + sum);
