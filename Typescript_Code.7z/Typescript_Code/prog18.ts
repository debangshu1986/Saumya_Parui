class Car { 
   //field 
   engine:string; 
   
   //constructor 
   constructor(engine:string) { 
      this.engine = engine 
   }  
   
   //function 
   disp():void { 
      console.log("Function displays Engine is  :   "+this.engine) 
   } 
} 

//create an object 
var car = new Car("XXSY1")

//access the field 
console.log("Reading attribute value Engine as :  "+car.engine)  

//access the function
car.disp()


// --------Inheritance
class Shape { 
    Area:number 
    
    constructor(a:number) { 
       this.Area = a 
    } 
 } 
 
class Circle extends Shape { 
    disp():void { 
        console.log("Area of the circle:  "+this.Area) 
    } 
}
   
var sh = new Circle(223); 
sh.disp()

// -----Method overriding
class PrinterClass { 
    doPrint():void {
        console.log("doPrint() from Parent called…") 
    } 
} 

class StringPrinter extends PrinterClass { 
    doPrint():void { 
        super.doPrint() 
        console.log("doPrint() is printing a string…")
    } 
} 
var pr = new StringPrinter() 
pr.doPrint()

//----static
class StaticMem {  
    static num:number; 
    
    static disp():void { 
       console.log("The value of num is"+ StaticMem.num) 
    } 
} 
 
StaticMem.num = 12     // initialize the static variable 
StaticMem.disp()      // invoke the static method

//------instanceof
class Person{ } 
var p = new Person() 
var isPerson = p instanceof Person; 
console.log(" obj is an instance of Person " + isPerson);

//-------Access specifier
class A { 
    public str:string = "hello" 
    private str2:string = "world" 
    protected str3:string;

    getstr2():string {
        return this.str2;
    }
}
class B extends A{
    setstr3(data:string) {
        this.str3 = data;
    }
}
  
var a = new A() 
var b = new B()
console.log(a.str)     //accessible 
console.log(a.getstr2())  
b.setstr3("test");

//----Interface

interface ILoan { 
    interest:number 
} 
 
class AgriLoan implements ILoan { 
    interest:number 
    rebate:number 
    
    constructor(interest:number,rebate:number) { 
       this.interest = interest 
       this.rebate = rebate 
    } 
} 
 
var agri = new AgriLoan(10,1) 
console.log("Interest is : "+agri.interest+" Rebate is : "+agri.rebate )