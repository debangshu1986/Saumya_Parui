var num = 2;    // data type inferred as  number 
console.log("value of num "+num); 
num = "12";
console.log(num);