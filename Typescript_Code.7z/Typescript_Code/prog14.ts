//concat
var arr1 = ["a", "b", "c"]; 
var arr2 = ["this", "is", "test"];

var arr = arr1.concat(arr2); 
console.log(arr);

//forEach
var num = [7, 8, 9];
num.forEach(function (value) {
    console.log(value);
});

// join
var carr = new Array("First","Second","Third"); 
          
var str = carr.join(); 
console.log("str : " + str );  
          
var str = carr.join(", "); 
console.log("str : " + str );  
          
var str = carr.join(" + "); 
console.log("str : " + str );

//map
var officers = [
    { id: 20, name: 'Captain Piett' },
    { id: 24, name: 'General Veers' },
    { id: 56, name: 'Admiral Ozzel' },
    { id: 88, name: 'Commander Jerjerrod' }
  ];

var officersIds = officers.map(function (officer) {
    return officer.id
});
console.log(officersIds);

//pop
var numbers = [1, 4, 9];          
var element = numbers.pop(); 
console.log("element is : " + element );  
var element = numbers.pop(); 
console.log("element is : " + element );

//push
var numbers = new Array(1, 4, 9); 
var length = numbers.push(10); 
console.log("new numbers is : " + numbers );  
length = numbers.push(20); 
console.log("new numbers is : " + numbers );

//reverse
var arr3 = [0, 1, 2, 3].reverse(); 
console.log("Reversed array is : " + arr3 );

//shift
var arr4 = [10, 1, 2, 3].shift(); 
console.log("Shifted value is : " + arr4 );

//unshift
var arr5 = new Array("orange", "mango", "banana", "sugar"); 
var length = arr.unshift("water"); 
console.log("Returned array is : " + arr5 );
console.log("Length of the array is : " + length );

//sort
var arr6 = new Array("orange", "mango", "banana", "sugar"); 
var sorted = arr6.sort(); 
console.log("Returned string is : " + sorted );

//splice
var arr7 = ["orange", "mango", "banana", "sugar", "tea"];  
var removed = arr7.splice(2, 0, "water");  
console.log("After adding 1: " + arr7 );  
console.log("removed is: " + removed); 
          
removed = arr7.splice(3, 1);  
console.log("After removing 1: " + arr7 );  
console.log("removed is: " + removed);

//reduce
var total = [0, 1, 2, 3].reduce(function(a, b){ return a + b; }); 
console.log("total is : " + total );