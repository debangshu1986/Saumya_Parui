import { PRINT_HELLOWORLD, PRINT_NAME } from './action-type';
export const printHelloWorld = () =>{
    // We can do api call here
    return {
        type: PRINT_HELLOWORLD,
        data: { message: "Hello world" }
    }
}

export const printName = () =>{
    // We can do api call here
    return {
        type: PRINT_NAME,
        data: { name: "Debangshu Nag" }
    }
}