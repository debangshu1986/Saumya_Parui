import { PRINT_HELLOWORLD, PRINT_NAME } from '../actions/action-type';

const initialState = {
    message: 'No Message',
    name: 'No Name'
}

const printMessageReducer = (state = initialState, { type, data }) => {
    switch(type) {
        case PRINT_HELLOWORLD:
            console.log(' I am reducer of print world ', state);
            data.name = state.name;
            return data;
        case PRINT_NAME:
            console.log(' I am reducer of print name ', state);
            data.message = state.message;
            return data;
        default:
            console.log(' I am default state ');
            return state;
    }
}

export default printMessageReducer;