import { combineReducers } from 'redux';
import printMessageReducer from './printMessageReducer';

const allReducers = combineReducers({
    printMessageReducer
});

export default allReducers;
