import { createStore } from 'redux';
import allReducers from './reducers/index';

const myStore = createStore(allReducers);

export default myStore;
