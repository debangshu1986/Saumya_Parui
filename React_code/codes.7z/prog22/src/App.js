import React, { Component } from 'react';
import { connect } from 'react-redux';
import { printHelloWorld, printName } from './actions/printMessageAction';

import './App.css';

class App extends Component{

   printHelloWorld = () =>{
      console.log('Hello world props');
      this.props.hello(); // Calling mapsDispatchToProps
   }

   printMyName = () =>{
     console.log('Print Name');
     this.props.getName();
   }
   render() {
     return(
       <div>
          <h1> I am learning Redux in a very simple way</h1>
          <button onClick={ this.printHelloWorld }>Set Message</button>
          { this.props.message }
          <br/>
          <button onClick={ this.printMyName }>Get Name</button>
          { this.props.name }
       </div>
     );
   }
}

const mapDispatchToProps = {
    hello: printHelloWorld,
    getName: printName
}

const mapStateToProps = (state) =>{
  
  console.log('map state to prop', state.printMessageReducer.message);

  return {
    message: state.printMessageReducer.message,
    name: state.printMessageReducer.name
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
