import React from 'react';

class Header extends React.Component {
   render() {
      return (
         <div>
            <h1>{this.props.headerProp}</h1>
         </div>
      );
   }
}
class Content extends React.Component {
   render() {
      return (
         <div>
            <h1>{this.props.contentProp}</h1>
         </div>
      );
   }
}
class App extends React.Component {
   constructor(props) {
      super(props);
      this.state = {
         headerData: "Header",
         contentData: "Content"
      }
   }
   render() {
      return (
         <div>
            <Header headerProp={this.state.headerData} />
            <Content contentProp={this.state.contentData}/>
         </div>
      );
   }
}
export default App;