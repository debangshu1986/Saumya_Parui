import React from 'react';
import './App.css';

class App extends React.Component {
  render() {
     return (
        <div>
           <h1>Header</h1>
           <h2>Content</h2>
           <p>This is the content!!!</p>
        </div>
     );
  }
}
export default App;