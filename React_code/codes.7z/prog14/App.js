import React from 'react';

class App extends React.Component {
   
   render() {
      return (
         <div>
            <Header></Header>
         </div>
      );
   }
}
class Header extends React.Component {
   
   /*
   componentWillMount() {
      console.log('componentWillMount!')
   }
   componentWillReceiveProps(newProps) {    
      console.log('componentWillReceiveProps!')
   }
   componentWillUpdate(nextProps, nextState) {
      console.log('componentWillUpdate!');
   }
   */
   constructor(props) {
      super(props);
      this.state = {favoritecolor: "red"};
      console.log('constructor!');
    }
   
   getSnapshotBeforeUpdate(prevProps, prevState) {
     document.getElementById("div1").innerHTML =
     "Before the update, the favorite was " + prevState.favoritecolor;
     return true;
   }
   componentDidUpdate() {
     document.getElementById("div2").innerHTML =
     "The updated favorite is " + this.state.favoritecolor;
     console.log('componentDidUpdate!')
   }
   shouldComponentUpdate(newProps, newState) {
      console.log('shouldComponentUpdate!');
      return true;
   }
   componentDidMount() {
      setTimeout(() => {
        this.setState({favoritecolor: "yellow"})
      }, 1000);
      console.log('componentDidMount!')
    }
   componentWillUnmount() {
      console.log('componentWillUnmount!')
   }
   static getDerivedStateFromProps(props, state) {
      console.log('getDerivedStateFromProps!');
      return true;
   }
   render() {
     return (
       <div>
       <h1>My Favorite Color is {this.state.favoritecolor}</h1>
       <div id="div1"></div>
       <div id="div2"></div>
       </div>
     );
   }
 }

export default App;